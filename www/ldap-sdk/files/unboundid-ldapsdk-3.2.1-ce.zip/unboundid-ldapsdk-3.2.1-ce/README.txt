UnboundID LDAP SDK for Java (Commercial Edition)
Copyright 2008-2017 UnboundID Corp.  All Rights Reserved.

This package contains Commercial Edition of the UnboundID LDAP SDK for Java.
It contains the following elements:

- unboundid-ldapsdk-ce.jar -- The UnboundID LDAP SDK for Java library
  (Commercial Edition).

- docs/index.html -- A list of available documentation.

- examples -- A directory containing source code for example programs that
  illustrate the use of the LDAP SDK.

- LICENSE.txt -- Information about the licenses under which the Commercial
  Edition of the UnboundID LDAP SDK for Java may be used.

