UnboundID LDAP SDK for Java
Copyright 2008-2019 Ping Identity Corporation  All Rights Reserved.

This package contains UnboundID LDAP SDK for Java.
It contains the following elements:

- unboundid-ldapsdk.jar -- The UnboundID LDAP SDK for Java library.

- docs/index.html -- A list of available documentation.

- examples -- A directory containing source code for example programs that
  illustrate the use of the LDAP SDK.

- LICENSE.txt -- Information about the licenses under which the LDAP SDK may be
  used.
